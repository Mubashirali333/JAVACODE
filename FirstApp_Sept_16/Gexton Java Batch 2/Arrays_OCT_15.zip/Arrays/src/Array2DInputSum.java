/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Salman
 */
import java.util.Scanner;
public class Array2DInputSum {
   public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        int[][] numbers = new int[3][6];
        int sum = 0;        
        for(int i=0; i<numbers.length; i++)
        {
            System.out.println("Enter Data for Row " + i);
            for(int j=0; j<numbers[i].length - 1; j++)
            {                
                System.out.print("Enter Value for numbers[" + i + "][" + j + "] : ");
                numbers[i][j] = input.nextInt();
                sum += numbers[i][j];
            } 
            numbers[i][5] = sum;
            sum = 0;
        }
        
        System.out.println("\n\nPRinting VAlues : ");
        for(int i=0; i<numbers.length; i++)
        {
            System.out.println("Data of Row " + i);
            for(int j=0; j<numbers[i].length; j++)
            {   
                if(j == 5)
                    System.out.println("Sum is " + numbers[i][j]);
                else
                    System.out.println("Value at numbers[" + i + "][" + j + "] : " + numbers[i][j]);
            }
        }
    } 
}
