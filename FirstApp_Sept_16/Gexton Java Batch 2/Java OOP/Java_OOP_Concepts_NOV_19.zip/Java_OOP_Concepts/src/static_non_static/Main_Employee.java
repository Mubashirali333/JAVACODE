/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package static_non_static;

/**
 *
 * @author Salman
 */
public class Main_Employee {
    public static void main(String[] args) {
        
        System.out.println("Total Employees " + Employee.total_objects);
        
        Employee obj1 = new Employee(101, "Zubair", "Software Engineer");
        Employee obj2 = new Employee(105, "Farhan", "System Analyst");
        
        System.out.println("Total Employees " + Employee.total_objects);
        
    }
}
