/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Salman
 */
public class MainJoinThread {
    
     public static void main(String[] args) {
        
        ThreadJoin obj1 = new ThreadJoin("First");
        ThreadJoin obj2 = new ThreadJoin("Second");
        ThreadJoin obj3 = new ThreadJoin("Third");
        
        System.out.println(obj1.objThread.getName() + " Alive : " + obj1.objThread.isAlive());
        System.out.println(obj2.objThread.getName() + " Alive : " + obj2.objThread.isAlive());
        System.out.println(obj3.objThread.getName() + " Alive : " + obj3.objThread.isAlive());
        
        try
        {
            System.out.println("\nMain Method is Waiting For Child Threads to Finish");
            obj1.objThread.join();
            obj2.objThread.join();
            obj3.objThread.join();
        }
        catch(InterruptedException ex)
        {
            System.out.println("Exception : Main Thread is interrupted" );
        }
        System.out.println("\n\nAfter join");
        System.out.println(obj1.objThread.getName() + " Alive : " + obj1.objThread.isAlive());
        System.out.println(obj2.objThread.getName() + " Alive : " + obj2.objThread.isAlive());
        System.out.println(obj3.objThread.getName() + " Alive : " + obj3.objThread.isAlive());

    }

}
