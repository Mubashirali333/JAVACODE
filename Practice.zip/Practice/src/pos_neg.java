/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author MR
 */
import java.util.Scanner;

public class pos_neg {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("Enter number : ");
        int num = input.nextInt();
//        if (num < 0) {
//            System.out.println("Number is negative ");
//        } else {
//            System.out.println("Number is postive ");
//        }

// second scenario
        if (num > 0) {
            System.out.println("Number is postive ");
        } else {
            System.out.println("Number is negtive ");
        }
    }

}
