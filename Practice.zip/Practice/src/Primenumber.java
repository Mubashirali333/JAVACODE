/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author MR
 */
import java.util.Scanner;

public class Primenumber {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.print("Enter number : ");
        int num = input.nextInt();
        for (int i = 0; i < num; i++) {
            if (num % 2 == 0) {
                System.out.print("Not Prime");
                break;
            } else {
                System.out.println("Prime ");
                break;
            }
        }

    }
}
