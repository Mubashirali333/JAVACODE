/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package abstraction;

/**
 *
 * @author Salman
 */
public class SuzukiCar extends Vechile {

    @Override
    public void Accelerate() {
        System.out.println("Accelearate speed 110 KM/h");
    }
    
}
