/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Salman
 */
import java.util.Scanner;
public class String_Demo 
{
    public static void main(String[] args) 
    {
        Scanner input = new Scanner(System.in);
//        System.out.print("Enter First String ");
//        String str1 = input.nextLine();
//        System.out.print("Enter Second String ");
//        String str2 = input.nextLine();
//        
//        if(str1.equals(str2))
//            System.out.println("Both Strings are equal");
//        else
//            System.out.println("Sorry Strings are not equal");
//        
//        System.out.println("Length of first String " + str1 + " is " + str1.length());
//        
//        int i = str1.compareTo(str2);
//        System.out.println("Value in i is " + i);
//        
        String msg = "Ahmed Ali Memon";
        System.out.println("ASCII CODE " + msg.codePointAt(0));
        
        String msg1 = msg.replace(" ", "*");        
        System.out.println("After Replace " + msg1);
        
        int index = msg.indexOf("m");
        System.out.println("First occurance of m in msg is at index " + index);
        index = msg.lastIndexOf("m");
        System.out.println("last occurance of m in msg is at index " + index);
        
        String path = "D:\\java programs\\Batch_2\\String_StringBuilder_Buffer\\src\\String_Demo_StringBuilder.java";
        
        index = path.lastIndexOf("\\") + 1;
        
        String filename = path.substring(index);
        System.out.println("FileName with extension is " + filename);
        
        int dot = path.lastIndexOf(".");
        filename = path.substring(index, dot);
        System.out.println("FileName without extension is " + filename);
        
        char[] ch = msg.toCharArray();
        for(int i=0; i<ch.length; i++)
            System.out.println("Character at index " + i + " is " + ch[i]);
    
    }
}
