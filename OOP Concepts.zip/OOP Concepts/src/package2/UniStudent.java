/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package package2;

import models.Student;

/**
 *
 * @author CS_GCH
 */
public class UniStudent extends Student {
    
}
