
/**
 *
 * @author MR
 */
import java.util.Scanner;

public class Login {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("Enter user ");
        String user = input.nextLine();
        System.out.println("Enter password");
        String pass = input.nextLine();
        if (user.equals("user")) {
            if (pass.equals("password")) {
                System.out.println("Login");
            }
        } else {
            System.out.println("Invalid");

        }
    }
}
