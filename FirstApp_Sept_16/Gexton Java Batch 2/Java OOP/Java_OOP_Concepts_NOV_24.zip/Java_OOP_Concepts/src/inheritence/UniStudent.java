/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package inheritence;

/**
 *
 * @author Salman
 */
public class UniStudent extends Student {
    String DeptName;
    String UniName;

    public String getDeptName() {
        return DeptName;
    }

    public void setDeptName(String DeptName) {
        this.DeptName = DeptName;
    }

    public String getUniName() {
        return UniName;
    }

    public void setUniName(String UniName) {
        this.UniName = UniName;
    }

    @Override
    public void DisplayInformation() {
        super.DisplayInformation(); //To change body of generated methods, choose Tools | Templates.
        System.out.println("Department Name : " + DeptName);
        System.out.println("University Name : " + UniName);
    }
    
}
