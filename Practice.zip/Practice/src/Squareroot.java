
/**
 *
 * @author MR
 */
import java.lang.Math;
import java.util.Scanner;

public class Squareroot {

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        int num1 = input.nextInt();
        System.out.println(Math.pow(num1,0.5));
        
        
    }

}
