/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Salman
 */
import java.util.Scanner;
public class while_loop_table {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        System.out.print("Enter the Table Number : ");
        int tableNum = input.nextInt();
        
        int i =1;
        while(i<=10)
        {
            System.out.println(tableNum + " * " + i + " = " + tableNum * i);
            i++;
        }
        
    }
}
