/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Salman
 */
import javax.swing.JFrame;

public class JFrame_Coding1 extends JFrame {
    public static void main(String[] args) {
        JFrame_Coding1 frm = new JFrame_Coding1();
        frm.setSize(700, 500);
        frm.setTitle("First GUI Application");
        frm.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frm.setVisible(true);
    }
}
