/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package inheritence;

/**
 *
 * @author Salman
 */
public class Child extends Parent {

    public Child() {
        super(105,"Rizwan Khan");
        System.out.println("Child Class : Zero Argument Constructor");
    }
    
    public void display()
    {
       System.out.println("ID is " + getId());
       System.out.println("Name is " + getName());
    }
    
    
}
