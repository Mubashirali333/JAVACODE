
/**
 *
 * @author MR
 */
import java.util.Scanner;

public class continiousinput {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        while (true) {
            System.out.println("Enter number : ");
            String inp = input.nextLine();
            if (inp.equals("Y") | inp.equals("y")) {
                break;
            }

        }
    }
}
