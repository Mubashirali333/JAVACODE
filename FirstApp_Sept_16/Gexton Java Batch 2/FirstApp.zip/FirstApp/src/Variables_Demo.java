/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Salman
 */
public class Variables_Demo {
    
    public static void main(String[] args) {
        // creating variables and initializing them with values
        
        int stid = 101; 
        String name = "Salman Qazi";
        String fname = "Zamir Hussain";
        char gender = 'M';
        String contactno = "+923331234567";        
        boolean check = true;
        
        System.out.println("Printing Variables Data");
        System.out.println("Student id : " + stid);
        System.out.println("Student Name : " + name);
        System.out.println("Father Name : " + fname);
        System.out.println("Gender " + gender);
        System.out.println("Contact No " + contactno);
        System.out.println("Value in Check " + check);
    }
}
