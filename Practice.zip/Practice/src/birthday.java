/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author MR
 */
import java.util.Scanner;
public class birthday {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("Enter year ");
        int year = input.nextInt();
        
        System.out.println(2022-year );
        
        
    }
}
