/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package abstraction;

/**
 *
 * @author Salman
 */
public class MainClass {
    public static void main(String[] args) {
       ToyotaCar c = new ToyotaCar();
       c.setDoors(4);
       
       System.out.println("\n\nInformation of TOYOTA CAR");
       c.Accelerate();
       System.out.println("No of doors are " + c.getDoors());
       
       System.out.println("\n\nInformation of SUZUKI CAR");
       SuzukiCar s = new SuzukiCar();
       s.setDoors(4);
       s.Accelerate();
       System.out.println("No of doors are " + s.getDoors());
    }
}
