/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Salman
 */
public class intArray {
    public static void main(String[] args) {
        int[] numbers = new int[5];
//        int num;
//        num = 90;
        
        numbers[0] = 50;
        numbers[1] = 100;
        numbers[2] = 500;
        numbers[3] = 120;
        numbers[4] = 75;
        
        int sum = numbers[0] + numbers[1] + numbers[2] + numbers[3] + numbers[4];
        
        System.out.println("Value at numbers[0] : " + numbers[0]);
        System.out.println("Value at numbers[1] : " + numbers[1]);
        System.out.println("Value at numbers[2] : " + numbers[2]);
        System.out.println("Value at numbers[3] : " + numbers[3]);
        System.out.println("Value at numbers[4] : " + numbers[4]);
        System.out.println("Sum " + sum);
        
    }
}
