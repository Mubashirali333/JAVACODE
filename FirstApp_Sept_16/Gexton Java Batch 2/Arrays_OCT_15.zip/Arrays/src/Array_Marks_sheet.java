/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Salman
 */
import java.util.Scanner;
public class Array_Marks_sheet {
    public static void main(String[] args) {
        
        Scanner input = new Scanner(System.in);
        String[][] marksheet = new String[5][11];
        
        String[] captions = {"Student ID", "Student Name",
        "Father Name", "English", "Physics", "Chemistry",
        "Mathematics", "Urdu", "Obtained Marks", 
        "Percentage", "Grade"};
        
        int obt_marks = 0;
        int marks;
        float per = 0.0f;
        String grade = "";
        String temp = "";        
        
        for(int i=0; i<marksheet.length; i++)
        {
            System.out.println("Enter Details for Student " + i);
            for(int j=0; j<8; j++)
            {
                if(j > 2)
                {
                    System.out.print("Enter " + captions[j] + " Marks : ");
                    temp = input.nextLine();
                    marksheet[i][j] = temp;
                    marks = Integer.parseInt(temp);
                    obt_marks += marks; 
                }
                else 
                {
                    System.out.print("Enter " + captions[j] + " : ");
                    marksheet[i][j] = input.nextLine();
                }
            }
            per = obt_marks * 100 / 500;
            if(per >= 80)
                grade = "A1";
            else if(per >= 70)
                grade = "A";
            else if(per >= 60)
                grade = "B";
            else if(per >= 50)
                grade = "C";
            else if(per >= 40)
                grade = "D";
            else if(per >= 33)
                grade = "E";
            else
                grade = "FAIL";
            marksheet[i][8] = String.valueOf(obt_marks);
            marksheet[i][9] = String.valueOf(per);
            marksheet[i][10] = grade;
            obt_marks = 0;
        }
        
        
        System.out.println("Printing VAlues");
        for(int i =0; i<marksheet.length; i++)
        {
            System.out.println("Record No " + i);
            for(int j =0; j<marksheet[i].length; j++)
            {
                if(j < 3)
                    System.out.println(captions[j] + " is : " + marksheet[i][j]);
                else if( j > 2 && j < 8)                   
                    System.out.println(captions[j] + " marks " + marksheet[i][j]);
                else
                    System.out.println(captions[j] + " : " + marksheet[i][j]);
            }
            System.out.println("\n");
        }
    }
}
