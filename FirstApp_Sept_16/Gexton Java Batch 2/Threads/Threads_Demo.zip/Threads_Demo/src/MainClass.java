/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Salman
 */
public class MainClass {
    
    public static void main(String[] args) {
        
        CustomThread custom1 = new CustomThread("Thread 1");
        CustomThread custom2 = new CustomThread("Thread 2");
        CustomThread custom3 = new CustomThread("Thread 3");
        //custom3.setPriority(Thread.MAX_PRIORITY);
        
        custom1.start();
        custom2.start();
        custom3.start();
    }
}
