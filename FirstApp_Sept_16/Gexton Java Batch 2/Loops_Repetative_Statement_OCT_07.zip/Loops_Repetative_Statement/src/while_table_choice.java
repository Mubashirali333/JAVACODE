/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Salman
 */
import java.util.Scanner;
public class while_table_choice {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int tablenum = 0;
        int start = 0; 
        int end = 0;
        char choice = 'y';
        String temp = "";
        
        while(choice == 'y' || choice == 'Y')
        {
           System.out.print("Enter table Number : ");
           temp = input.nextLine();
           tablenum = Integer.parseInt(temp);
           
           System.out.print("Enter start value for table : ");
           temp = input.nextLine();
           start = Integer.parseInt(temp);
           
           System.out.print("Enter end value for table : ");
           temp = input.nextLine();
           end = Integer.parseInt(temp);
           
           for(int i=start; i<=end; i++)
               System.out.println(tablenum + " * " + i + " = " + tablenum * i);
           
           System.out.print("Do you want to print another table [y/n] : ");
           choice = input.nextLine().charAt(0);
        }
    }
}
