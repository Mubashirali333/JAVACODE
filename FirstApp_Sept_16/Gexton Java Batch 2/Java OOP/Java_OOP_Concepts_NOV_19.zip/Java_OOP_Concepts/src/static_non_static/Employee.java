/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package static_non_static;

/**
 *
 * @author Salman
 */
public class Employee {
    public static int total_objects = 0;
    
    public Employee()
    {
        total_objects++;
    }

    public Employee(int empid, String empName, String designation) {
        this.empid = empid;
        this.empName = empName;
        this.designation = designation;
        total_objects++;
    }
    
    private int empid;
    private String empName;
    private String designation;

    public int getEmpid() {
        return empid;
    }

    public void setEmpid(int empid) {
        this.empid = empid;
    }

    public String getEmpName() {
        return empName;
    }

    public void setEmpName(String empName) {
        this.empName = empName;
    }

    public String getDesignation() {
        return designation;
    }

    public void setDesignation(String designation) {
        this.designation = designation;
    }
    
    
}
