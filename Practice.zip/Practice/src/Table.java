/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author MR
 */
import java.util.Scanner;

public class Table {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
//        int table, str, end;
//        System.out.println("Enter table number : ");
//        table = input.nextInt();
//        System.out.println("Enter start number : ");
//        str = input.nextInt();
//        System.out.println("Enter end number : ");
//        end = input.nextInt();
//
//        for (int i = str; i <= end; i++) {
//            System.out.println(table + " x " + i + " = " + i * table);
//        }
        System.out.println("Enter Table : ");
        int num = input.nextInt();
        System.out.println("Enter Starting Table : ");
        int str = input.nextInt();
        System.out.println("Enter Ending Table : ");
        int end = input.nextInt();
        for (int i = str; i <= end; i++) {
            System.out.println(num + " X " + i + " = " + i * num);
        }

    }

}
