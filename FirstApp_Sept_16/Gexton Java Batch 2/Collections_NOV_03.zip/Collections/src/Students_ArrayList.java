/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Salman
 */
import java.util.Scanner;
import java.util.ArrayList;

public class Students_ArrayList 
{
    public static void main(String[] args) 
    {
        Scanner input = new Scanner(System.in);
        ArrayList lstStudents = new ArrayList();
        Student obj = null;
        String temp = "";
        char choice = ' ';
        do 
        {
            System.out.println("Enter Information for Student ");
            System.out.print("Enter Student ID : ");
            temp = input.nextLine();
            int id = Integer.parseInt(temp);

            System.out.print("Enter Student Name : ");
            String name = input.nextLine();

            System.out.print("Enter Father Name : ");
            String fname = input.nextLine();
            
            obj = new Student();
            obj.setStudentID(id);
            obj.setStudentName(name);
            obj.setFatherName(fname);
            
            lstStudents.add(obj);            

            System.out.print("Do you want to ADD Another Record [y/n] : ");
            choice = input.nextLine().charAt(0);
        } while (choice == 'y' || choice == 'Y');

        System.out.println("\n\nPrinting Student Records");
        for (int i = 0; i < lstStudents.size(); i++) 
        {
            obj = (Student) lstStudents.get(i);
            System.out.println("\n\nStudent " + i + " Information");
            System.out.println("Student ID " + obj.getStudentID());
            System.out.println("Student Name " + obj.getStudentName());
            System.out.println("Father Name " + obj.getFatherName());
        }
    }
}
