/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Salman
 */
import java.util.Scanner;

public class Use_Students {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        Student obj = new Student();        
        String temp = "";    
        System.out.println("Enter Information for First Student");
        System.out.print("Enter Student ID : ");
        temp = input.nextLine();
        int id = Integer.parseInt(temp);
        
        System.out.print("Enter Student Name : ");
        String name = input.nextLine();
        
        System.out.print("Enter Father Name : ");
        String fname = input.nextLine();
        
        obj.setStudentID(id);
        obj.setStudentName(name);
        obj.setFatherName(fname);
        
//        
//      creating second object of student class

        Student obj1 = new Student();
        System.out.println("Enter Information for Second Student");
               
        System.out.print("Enter Student ID : ");
        temp = input.nextLine();
        id = Integer.parseInt(temp);
        
        System.out.print("Enter Student Name : ");
        name = input.nextLine();
        
        System.out.print("Enter Father Name : ");
        fname = input.nextLine();
        
        obj1.setStudentID(id);
        obj1.setStudentName(name);
        obj1.setFatherName(fname);

        
        System.out.println("Student Information : ");
        System.out.println("First Student Information");
        System.out.println("Student ID : " + obj.getStudentID());
        System.out.println("Student Name : " + obj.getStudentName());
        System.out.println("Father Name : " + obj.getFatherName());
        
         System.out.println("Second Student Information");
        System.out.println("Student ID : " + obj1.getStudentID());
        System.out.println("Student Name : " + obj1.getStudentName());
        System.out.println("Father Name : " + obj.getFatherName());
        
    }
}
