/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Salman
 */
public class Array2D {
    public static void main(String[] args) {
        int[][] numbers = new int[3][5];
        
        // put 90 value at row 0 and column 2
        // numbers[0][2] = 90;
        
        // storing data in row 0
        numbers[0][0] = 10;
        numbers[0][1] = 20;
        numbers[0][2] = 30;
        numbers[0][3] = 40;
        numbers[0][4] = 50;
        
         // storing data in row 1
        numbers[1][0] = 100;
        numbers[1][1] = 200;
        numbers[1][2] = 300;
        numbers[1][3] = 400;
        numbers[1][4] = 500;
                
         // storing data in row 2
        numbers[2][0] = 1000;
        numbers[2][1] = 2000;
        numbers[2][2] = 3000;
        numbers[2][3] = 4000;
        numbers[2][4] = 5000;
        
        System.out.println("Printing Data of Row 0 ");
        System.out.println("numbers[0][0] : " + numbers[0][0]);
        System.out.println("numbers[0][1] : " + numbers[0][1]);
        System.out.println("numbers[0][2] : " + numbers[0][2]);
        System.out.println("numbers[0][3] : " + numbers[0][3]);
        System.out.println("numbers[0][4] : " + numbers[0][4]);
        
        System.out.println("Printing Data of Row 1 ");
        System.out.println("numbers[1][0] : " + numbers[1][0]);
        System.out.println("numbers[1][1] : " + numbers[1][1]);
        System.out.println("numbers[1][2] : " + numbers[1][2]);
        System.out.println("numbers[1][3] : " + numbers[1][3]);
        System.out.println("numbers[1][4] : " + numbers[1][4]);
        
        System.out.println("Printing Data of Row 2 ");
        System.out.println("numbers[2][0] : " + numbers[2][0]);
        System.out.println("numbers[2][1] : " + numbers[2][1]);
        System.out.println("numbers[2][2] : " + numbers[2][2]);
        System.out.println("numbers[2][3] : " + numbers[2][3]);
        System.out.println("numbers[2][4] : " + numbers[2][4]);
    }
}
