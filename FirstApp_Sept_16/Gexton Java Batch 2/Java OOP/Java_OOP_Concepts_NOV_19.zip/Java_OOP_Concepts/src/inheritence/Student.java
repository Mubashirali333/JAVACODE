/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package inheritence;

/**
 *
 * @author Salman
 */
public class Student {
    private String stid;
    private String stname;
    private String fname;
    private String gender;
    private String address;
    private String contactno;
    private String email;   

    public String getStid() {
        return stid;
    }

    public void setStid(String stid) {
        this.stid = stid;
    }

    public String getStname() {
        return stname;
    }

    public void setStname(String stname) {
        this.stname = stname;
    }

    public String getFname() {
        return fname;
    }

    public void setFname(String fname) {
        this.fname = fname;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getContactno() {
        return contactno;
    }

    public void setContactno(String contactno) {
        this.contactno = contactno;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
    
    
    public void DisplayInformation()
    {
        System.out.println("Student id : " + this.stid);
        System.out.println("Student Name : " + this.stname);
        System.out.println("Father Name : " + this.fname);
        System.out.println("Gender : " + this.gender);
        System.out.println("Address : " + this.address);
        System.out.println("Email : " + this.email);
        System.out.println("Contact No : " + this.contactno);
    }
    
}
