/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Salman
 */
import java.util.Scanner;
import java.util.ArrayList;

public class ArrayList_Input {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        ArrayList objNames = new ArrayList();
        String name = "";
        char choice = ' ';
        do {
            System.out.print("Enter Student Name : ");
            objNames.add(input.nextLine());
//            name = input.nextLine();
//            objNames.add(name);
            System.out.print("Do you want to add another name [y/n] : ");
            choice = input.nextLine().charAt(0);           

        } while (choice == 'y' || choice == 'Y');
                
        System.out.println("\n\nPrinting Names\nTotal Names are : " + objNames.size());
        
        for(int i=0; i<objNames.size(); i++)
            System.out.println("Name at index " + i  + " is : " + objNames.get(i));
    }
}
