/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Salman
 */
public class CustomThread extends Thread {

    CustomThread(String name) {
        super.setName(name);
    }

    private String[] Courses = {"Java Programming",
        "Android Programming",
        "Graphics Designing",
        "Web Designing",
        "Web Development"};

    @Override
    public void run() {
        int i = 0;
        try {
            for (String course : Courses) {
                System.out.println(this.getName() + " : " + course);
                if (this.getName().equals("Thread 3")) {
                    Thread.sleep(1000);
                }
            }
        } catch (InterruptedException ex) {
        }
    }

}
