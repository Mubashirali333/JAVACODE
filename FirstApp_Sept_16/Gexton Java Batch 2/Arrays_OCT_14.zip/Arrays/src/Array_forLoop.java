/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Salman
 */
import java.util.Scanner;
public class Array_forLoop {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        int numbers[] = new int[5];
        int sum = 0;
        for(int i=0; i<numbers.length; i++)
        {
            System.out.print("Enter Value for number[" + i + "] : ");
            numbers[i] = input.nextInt();
            sum += numbers[i]; // sum = sum + numbers[i];
        }
        
        System.out.println("\n\nArrays Values");
        for(int i=0; i<numbers.length; i++)
            System.out.println("Value at numbers[" + i + "] is : " + numbers[i]);
        System.out.println("Sum " + sum);
    }
}
