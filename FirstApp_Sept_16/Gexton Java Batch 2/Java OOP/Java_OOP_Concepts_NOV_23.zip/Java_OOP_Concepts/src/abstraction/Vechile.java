/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package abstraction;

/**
 *
 * @author Salman
 */
public abstract class Vechile {
    
    private int doors;
    
    // non-concrete method (abstract method)
    public abstract void Accelerate();

    // concrete methods
    public int getDoors() {
        return doors;
    }

    public void setDoors(int doors) {
        this.doors = doors;
    }
    
    
    
}
