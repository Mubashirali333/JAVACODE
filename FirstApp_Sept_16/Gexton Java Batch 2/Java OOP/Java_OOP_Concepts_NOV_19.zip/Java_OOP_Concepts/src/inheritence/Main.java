/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package inheritence;

/**
 *
 * @author Salman
 */
public class Main {

    public static void main(String[] args) {
        //Parent p = new Parent();
        Child c = new Child();
        c.display();
//        System.out.println("Student ID : " + c.getId());
//        System.out.println("Stuent Name : " + c.getName());

//        Creating object of SchoolStudent class
        SchoolStudent obj = new SchoolStudent();
        obj.setStid("Student105478");
        obj.setStname("Ahmed Ali");
        obj.setFname("Kamran");
        obj.setAddress("Hyderabad");
        obj.setEmail("ali@gmail.com");
        obj.setContactno("445454545");
        obj.setGender("Male");
        obj.setClassname("Matric");
        obj.setSchoolName("ABC Foundation");
        
        obj.DisplayInformation();
    }
}
