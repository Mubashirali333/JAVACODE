/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Salman
 */
import java.util.Scanner;
public class do_while_addition {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        int num1 = 0;
        int num2 = 0;
        int result = 0;
        
        char choice = ' ';
        String temp = null;
        
        do{
            System.out.print("Enter First Integer Number : ");
            temp = input.nextLine();
            num1 = Integer.parseInt(temp);
            System.out.print("Enter Second Integer Number : ");
            temp = input.nextLine();
            num2 = Integer.parseInt(temp);
            result = num1 + num2;
            System.out.println("Addition : " + num1 + " + " + num2 + " = " + result);
           
            System.out.print("Do you want to perform Addition Again? y/n : ");
            choice = input.nextLine().charAt(0);
        }
        while(choice == 'y' || choice == 'Y');
    }
}
