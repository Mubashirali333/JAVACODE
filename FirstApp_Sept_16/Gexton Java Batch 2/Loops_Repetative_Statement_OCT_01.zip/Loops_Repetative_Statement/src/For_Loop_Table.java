/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Salman
 */
import java.util.Scanner;
public class For_Loop_Table {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.print("Enter Table Number : ");
        int tableNum = input.nextInt();
        
//        System.out.println(tableNum + " X 1 = " + (tableNum * 1) );
//        System.out.println(tableNum + " X 2 = " + (tableNum * 2) );
//        System.out.println(tableNum + " X 3 = " + (tableNum * 3) );
    
//        for(int i=1; i<=100; i++)
//            System.out.println(tableNum + " X " + i + " = " +  tableNum * i);
//    
//        System.out.print("Enter end value for table : ");
//        int endvalue = input.nextInt();
        
//        for(int i=1; i<=endvalue; i++)
//            System.out.println(tableNum + " X " + i + " = " +  tableNum * i);
    
       System.out.print("Enter start value for table : ");
       int start = input.nextInt();
       
       System.out.print("Enter end value for table : ");
        int endvalue = input.nextInt();
       
       for(int i = start; i<= endvalue; i++)
           System.out.println(tableNum + " X " + i + " = " +  tableNum * i);
    }
}
