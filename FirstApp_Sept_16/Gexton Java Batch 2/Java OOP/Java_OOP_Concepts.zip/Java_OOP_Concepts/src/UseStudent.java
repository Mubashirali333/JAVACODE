/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Salman
 */
public class UseStudent {
    public static void main(String[] args) {
        
        Student obj = new Student(15, "Kmran Khan", "Muhammad Haneef");
        Student obj1 = new Student();
        
        System.out.println("Student id is : " + obj.getStudentID());
        System.out.println("Student Name : " + obj.getStudentName());
        System.out.println("Father Name : " + obj.getFatherName());
        
        obj.setStudentName("Kamran Khan");
        obj.setFatherName("Muhammad Hanif");
        System.out.println("\n\nAfter Correction");
        System.out.println("Student id is : " + obj.getStudentID());
        System.out.println("Student Name : " + obj.getStudentName());
        System.out.println("Father Name : " + obj.getFatherName());
        
        System.out.println("\n\nOBJ1");
        System.out.println("Student id is : " + obj1.getStudentID());
        System.out.println("Student Name : " + obj1.getStudentName());
        System.out.println("Father Name : " + obj1.getFatherName());
        
        
    }
    
    
    
}
