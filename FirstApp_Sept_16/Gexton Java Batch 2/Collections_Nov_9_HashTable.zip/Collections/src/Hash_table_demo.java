/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Salman
 */
import java.util.Scanner;
import java.util.Hashtable;

public class Hash_table_demo {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        Hashtable obj = new Hashtable();
        obj.put(1, "Kamran");
        obj.put(2,"Salman");
        obj.put(3, "Faisal");
        obj.put(1, "Ahmed Ali");
        obj.put("123", 34343);
        
        System.out.println(obj);
        
        // Generic Hashtable
        
        Hashtable<Integer, String> objItems = new Hashtable<>();
       
    }
}
