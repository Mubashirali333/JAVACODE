/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Salman
 */
public class Student {    
    // Constructors 
    public Student()
    {
        
    }
    
    public Student(int id, String name, String fname)
    {
        this.studentID = id;
        this.studentName = name;
        this.fatherName = fname;
    }
    
    public Student(String name, String fname, int id)
    {
        this.studentID = id;
        this.studentName = name;
        this.fatherName = fname;
    }
    
    // data members / variables
    private int studentID;
    private String studentName;
    private String fatherName;

    public int getStudentID() {
        return studentID;
    }

    public void setStudentID(int studentID) {
        this.studentID = studentID;
    }

    public String getStudentName() {
        return studentName;
    }

    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }

    public String getFatherName() {
        return fatherName;
    }

    public void setFatherName(String fatherName) {
        this.fatherName = fatherName;
    }
    
   
}
