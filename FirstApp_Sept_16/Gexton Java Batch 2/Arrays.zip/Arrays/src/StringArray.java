/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Salman
 */
import java.util.Scanner;
public class StringArray {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        String names[] = new String[5];
        int i = 0;
        while(i<names.length)
        {
            System.out.print("Enter name " + i + " : ");
            names[i] = input.nextLine();
            i++;
        }
        
        System.out.println("\n\nPRinting Names");
        i = 0;
        do
        {
            System.out.println("Name at " + i + " is : " + names[i]);
            i++;
        }
        while(i<names.length);        
    }
}
