/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Salman
 */
public class Student {
//    private members of class are only accessible in a class
//    in which they are declared.
//    we have to use methods for assigning and getting values
//    to these private memebers
    
    
//    private members (attributes) of a student class
    private int studentID;
    private String studentName;
    private String fatherName;
    
//    public methods (operations) of a student class
//    these methods are use for assigning and getting values
//    to the above declared private members
    
    public void setStudentID(int id)
    {
        this.studentID = id;
    }
    
    public int getStudentID()
    {
        return this.studentID;
    }

    public String getStudentName() {
        return studentName;
    }

    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }

    public String getFatherName() {
        return fatherName;
    }

    public void setFatherName(String fatherName) {
        this.fatherName = fatherName;
    }
    
    
}
