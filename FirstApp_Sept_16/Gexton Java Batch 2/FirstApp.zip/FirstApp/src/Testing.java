/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Salman
 */
public class Testing {    
    public static void main(String args[])
    {
//        here System is language provided class
        System.out.println("Welcome To Gexton Education");
        System.out.println("Hello Students");
    }
}
