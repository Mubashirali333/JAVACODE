/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Salman
 */
public class ThreadJoin implements Runnable {
    
    Thread objThread;
    String name;
    
    public ThreadJoin(String name)
    {
        this.name = name;
        objThread = new Thread(this, name);
        System.out.println(objThread.getName() + " is Started");
        objThread.start();
    }
    
     @Override
    public void run() {
        try
        {
            for (int count=1; count<=3; count++)
            {
                System.out.println(count + " : " + name);
                Thread.sleep(1000);
            }
        }
        catch(InterruptedException ex)
        {
            System.out.println(name + " Thread Interrupted");
        }
        System.out.println(name + " Thread Exiting");

    }
}
