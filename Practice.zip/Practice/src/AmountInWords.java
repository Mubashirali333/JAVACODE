
/**
 *
 * @author MR
 */
import java.util.Scanner;

public class AmountInWords {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Enter a 5 digit amount : ");
        int amount = input.nextInt();

//        int thousands = amount / 1000;
//        int temp = amount % 1000;
//        
//        int hundreds = temp / 100;
//        temp = temp % 100;
//        
//        int tens = temp / 10;
//        int ones = temp % 10;
//        
//        System.out.println(amount + " Contains : ");
//        System.out.println(thousands + " Thousands");
//        System.out.println(hundreds + " Hundreds");
//        System.out.println(tens + " Tens");
//        System.out.println(ones + " Ones");        
        int thousand = amount / 10000;
        int temp = amount % 1000;

        int hundread = temp / 100;
        temp = temp % 100;

        int ten = temp / 10;
        int ones = temp % 10;

        System.out.println(amount + " Contains : ");
        System.out.println(thousand + " thousand");
        System.out.println(hundread + " hundread");
        System.out.println(ten + " ten");
        System.out.println(ones + " ones");

    }
}
