/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Salman
 */
import java.util.ArrayList;
import java.util.Iterator;

public class ArrayList_Demo {

//    ArrayList is a class in a java.util package
//    It is basically a collection in which we can store
//    data of any type (int, float, char, double etc)
//    Data in ArrayList is stored in an object format
//    ArrayList size is not fixed, its size can be grow
//    or shrink according to the user's needs.
    public static void main(String[] args) {

        ArrayList obj = new ArrayList();
        // adding item at the last of arraylist
        obj.add("Gexton");
        obj.add("Latifabad");

        System.out.println(obj);

        // inserting / adding item a specific location
        obj.add(1, "Education");
        System.out.println("After adding item at location 1 : " + obj);
        
        obj.add(12323);
        obj.add(true);
        obj.add(43344.43f);
        obj.add('A');
        
        System.out.println(obj);
        
        // getting / accessing item from ArrayList
        
        System.out.println("ITem at index 2 is " + obj.get(2));
        
        // fetching all the items from ArrayList using Loop
        
        for(int i=0; i<obj.size(); i++)
            System.out.println("Value at index " + i + " is : " + obj.get(i));
        
       // All the collection classes have a iterator, through which
       // we can fetch the data from arraylist
       
       Iterator it = obj.iterator();
       System.out.println("\n\nPrinting Items using Iterator");
       while(it.hasNext())
           System.out.println("ITem value is " + it.next());
       
       
       // removing items from ArrayList (obj)
       if(obj.remove("Gexton55"))
           System.out.println("Items is removed successfully");
       else
           System.out.println("Sorry item doesn't exists");
       
       System.out.println("After remove list is \n" + obj);
    }
}
