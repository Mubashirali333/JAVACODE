/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Salman
 */
import java.util.Scanner;

public class Students_Array {

    public static void main(String[] args) 
    {
        Scanner input = new Scanner(System.in);
        Student[] obj = new Student[100];
        String temp = "";

        for (int i = 0; i < obj.length; i++) 
        {
            System.out.println("Enter Information for Student " + i);
            System.out.print("Enter Student ID : ");
            temp = input.nextLine();
            int id = Integer.parseInt(temp);

            System.out.print("Enter Student Name : ");
            String name = input.nextLine();

            System.out.print("Enter Father Name : ");
            String fname = input.nextLine();

            obj[i] = new Student();
            obj[i].setStudentID(id);
            obj[i].setStudentName(name);
            obj[i].setFatherName(fname);
        }
        
        
        System.out.println("\n\nPrinting Student Records");
        for (int i = 0; i < obj.length; i++) 
        {
            System.out.println("\n\nStudent " + i + " Information");
            System.out.println("Student ID " + obj[i].getStudentID());
            System.out.println("Student Name " + obj[i].getStudentName());
            System.out.println("Father Name " + obj[i].getFatherName());
        }
    }
}
