/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Salman
 */
import java.util.Scanner;
import java.util.Hashtable;

public class mini_project {
    Scanner input = new Scanner(System.in);
    Hashtable<Integer, Student> objStudents = new Hashtable<>();
    Student objStudent = null;
    String temp = null;
    
    public void displayMenu() {
        char choice = 'y';
        int op = 0;        
        do {
            System.out.println("\n===============================\n");
            System.out.println("| \t 1. Add Record \t |");
            System.out.println("| \t 2. Edit Record \t |");
            System.out.println("| \t 3. Delete Record \t |");
            System.out.println("| \t 4. Search Record \t |");
            System.out.println("| \t 5. Show All Records \t |");
            System.out.println("| \t 6. Exit \t |");
            System.out.println("\n===============================\n");

            System.out.print("Select an operation you want to perform : ");
            temp = input.nextLine();
            op = Integer.parseInt(temp);
            switch (op) {
                case 1:
                    AddRecord();
                    break;
                case 2:
                    EditRecord();
                    break;
                case 3:
                    DeleteRecord();
                    break;
                case 4:
                    SearchRecord();
                    break;
                case 5:
                    ShowAllRecords();
                    break;
                case 6:
                    System.exit(0);
            }
        } while (choice == 'y' || choice == 'Y');
    }

    private void AddRecord() {
        System.out.println("Operation : Add Student Record");
        System.out.print("Enter Student ID : ");
            temp = input.nextLine();
            int id = Integer.parseInt(temp);
            if (objStudents.containsKey(id)) {
                System.out.println("Sorry Record with this id already exists");
            } else {
                System.out.print("Enter Student Name : ");
                String name = input.nextLine();

                System.out.print("Enter Father Name : ");
                String fname = input.nextLine();

                objStudent = new Student();
                objStudent.setStudentID(id);
                objStudent.setStudentName(name);
                objStudent.setFatherName(fname);

                objStudents.put(id, objStudent);
            }
    }

    private void EditRecord() {
        System.out.println("Operation : Edit Student Record");
        System.out.print("Enter student id : ");
        temp = input.nextLine();
        int id = Integer.parseInt(temp); 
        char choice = ' ';
        if(objStudents.containsKey(id))
        {
            objStudent = objStudents.get(id); 
            System.out.println("Name is : " + objStudent.getStudentName());
            System.out.print("do you want to change Student Name [y/n]: ");
            choice = input.nextLine().charAt(0);
            
            if(choice == 'y' || choice == 'Y')
            {
                System.out.print("Enter Updated Student Name : ");
                objStudent.setStudentName(input.nextLine());
            }
            
            System.out.println("Father Name is : " + objStudent.getFatherName());
            System.out.print("do you want to change Father Name [y/n]: ");
            choice = input.nextLine().charAt(0);
            
            if(choice == 'y' || choice == 'Y')
            {
                System.out.print("Enter Updated Father Name : ");
                objStudent.setFatherName(input.nextLine());
            }
            
            System.out.println("Record Successfully Updated");
           
        }
        else
            System.out.println("Sorry Record with ID " + id + " Dosen't Exists");
        
    }

    private void DeleteRecord() {
        System.out.println("Operation : Delete Student Record");
        System.out.print("Enter student id : ");
        temp = input.nextLine();
        int id = Integer.parseInt(temp);
        
        if(objStudents.containsKey(id))
        {
            objStudents.remove(id);
            System.out.println("Record Successfully Deleted");
        }
        else
            System.out.println("Sorry Record with ID " + id + " Dosen't Exists");
        
    }

    private void SearchRecord() {
        System.out.println("Operation : Search Student Record");
        System.out.print("Enter student id : ");
        temp = input.nextLine();
        int id = Integer.parseInt(temp);
        
        if(objStudents.containsKey(id))
        {
            objStudent = objStudents.get(id);            
            System.out.println("Student ID " + objStudent.getStudentID());
            System.out.println("Student Name " + objStudent.getStudentName());
            System.out.println("Father Name " + objStudent.getFatherName());
        }
        else
            System.out.println("Sorry Record with ID " + id + " Dosen't Exists");
        
    }
    
    private void ShowAllRecords()
    {
        System.out.println("\nShowing All Records");
        Object[] keys = objStudents.keySet().toArray();
        int key =0;
        for(int i=0; i<objStudents.size(); i++)
        {
            key = (int) keys[i];
            objStudent = objStudents.get(key);
            
            System.out.println("\n\nStudent " + i + " Information");
            System.out.println("Student ID " + objStudent.getStudentID());
            System.out.println("Student Name " + objStudent.getStudentName());
            System.out.println("Father Name " + objStudent.getFatherName());
        }
    }
}
