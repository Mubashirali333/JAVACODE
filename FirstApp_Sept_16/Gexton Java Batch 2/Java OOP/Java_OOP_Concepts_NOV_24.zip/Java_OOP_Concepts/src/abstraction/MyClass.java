/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package abstraction;

/**
 *
 * @author Salman
 */


public class MyClass {
    public static void main(String[] args) {
        Cat objCat = new Cat();
        Dog objDog = new Dog();
        
        objCat.sound();
        objCat.eat();
        
        objDog.sound();
        objDog.eat();        
        
        // Parent class / Interface can hold the reference of child class
        System.out.println("\n\n");
        IAnimal animal = new Dog();
        animal.sound();
        animal.eat();
    }
}
