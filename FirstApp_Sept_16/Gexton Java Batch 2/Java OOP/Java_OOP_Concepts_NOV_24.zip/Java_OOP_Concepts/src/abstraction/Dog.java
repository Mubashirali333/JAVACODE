/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package abstraction;

/**
 *
 * @author Salman
 */
import inheritence.Student;
public class Dog extends Student implements IAnimal {
    
    @Override
    public void sound() {
        System.out.println("Dog sound is wooo wooo");
    }

    @Override
    public void eat() {
        System.out.println("Dog can eat meat");
    }
    
}
