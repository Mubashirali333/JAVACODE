/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Salman
 */
import java.util.ArrayList;
import java.util.Iterator;

public class Generic_ArrayList {
    public static void main(String[] args) {
        
        ArrayList<String> names = new ArrayList<String>();
        ArrayList<Float> per = new ArrayList<>();
        ArrayList<Integer> numbers = new ArrayList<>();
        
        names.add("Salman");
        names.add("Faisal");
        names.add("Arsalan");
        names.add(0, "Gexton Education");
        
        
        for(int i=0; i<names.size(); i++)
            System.out.println("NAme is " + names.get(i));
        
        System.out.println("\n\nUsing Iterators\n");
        Iterator<String> it = names.iterator();
        while(it.hasNext())
            System.out.println("NAme is " + it.next());
    }
}
