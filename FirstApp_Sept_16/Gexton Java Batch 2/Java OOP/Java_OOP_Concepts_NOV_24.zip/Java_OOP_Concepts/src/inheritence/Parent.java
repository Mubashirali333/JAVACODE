/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package inheritence;

/**
 *
 * @author Salman
 */
public class Parent {

    private int id;
    private String name;

    public Parent() {
        System.out.println("Parent Class : Zero Argument Constructor");
    }

    public Parent(int id, String name) {
        System.out.println("Parent Class : Two Argument Constructor");
        this.id = id;
        this.name = name;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    
    
}
