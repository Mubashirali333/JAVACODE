/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Salman
 */
public class format_Specifier {
    public static void main(String[] args) {
        float per = 3.14785f;
        System.out.println("Percentage is " + per);
        System.out.format("Percentage is %f %n", per);
        System.out.format("Percentage is %.3f %n", per);
    }
}
