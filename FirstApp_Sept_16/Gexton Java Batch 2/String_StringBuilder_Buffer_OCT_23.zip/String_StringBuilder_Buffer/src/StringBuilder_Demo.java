/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Salman
 */
import java.util.Scanner;

public class StringBuilder_Demo {
    public static void main(String[] args) {
        
        Scanner input = new Scanner(System.in);
        
//        StringBuilder sb = new StringBuilder("Gexton");
//        System.out.println("Capcaity " + sb.capacity());
//        System.out.println("Length " + sb.length());
//        
//        System.out.print("enter Some data : ");
//        String data = input.nextLine();
//        sb.append(" ");
//        sb.append(data);
//        sb.append("\nStudent Name : " + data);
//        System.out.println("Values in sb : '" + sb.toString() + "'");
//        
//        sb.insert(2, "New Value");
//        System.out.println("Values in sb after insert : '" + sb.toString() + "'");
//        
//        =====================================
//      Deleting a word or string from a stringbuilder

//        StringBuilder sb1 = new StringBuilder("Welcome Hello Students To Gexton Education");
//        System.out.println("\n\nValue in sb1 is " + sb1);
//        
//        System.out.print("Enter word you want to delete from the above string : ");
//        String wordToDelete = input.nextLine();
//        
//        int startindex = sb1.indexOf(wordToDelete);
//        int endindex = startindex + wordToDelete.length() + 1;
//        
//       // System.out.println("Start " + startindex + "\n End " + endindex);
//        if(startindex >= 0) 
//        {
//            sb1.delete(startindex, endindex);
//            System.out.println("\n\nValue in sb1 after delete is " + sb1);
//        }
//        else
//            System.out.println("Sorry " + wordToDelete + " Not Found in string");
//        
//        =====================================
//          Replacing a text in a StringBuilder

//        StringBuilder sb2 = new StringBuilder("Java Programming");
//        System.out.println("Text in a sb2 : " + sb2);
//        
//        System.out.print("Enter a text you want to replace");
//        String txt = input.nextLine();
//        String wordToReplace = "Programming";
//        int rstart = sb2.indexOf(wordToReplace);
//        int rend = rstart + wordToReplace.length();
//        sb2.replace(rstart, rend, txt);
//        System.out.println("\n\nsb2 after replace method : " + sb2);
        
//        ====================================
//      insert a new text in a sb2

        StringBuilder sb3 = new StringBuilder("Java Programming");
        System.out.println("Text in a sb3 : " + sb3);
        
        System.out.print("Enter text you want to insert : ");
        String wordToInsert = input.nextLine() + " ";
        int position = sb3.indexOf("Programming");
        sb3.insert(position, wordToInsert);
        System.out.println("Text in sb3 after insert : " + sb3);
        
        //StringBuffer buffer = new StringBuffer();
       
    }
}
